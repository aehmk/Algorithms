#ifndef STD2DARRAYS_H
#define STD2DARRAYS_H

void fillArray(int rows, int cols, int** array);

#endif // STD2DARRAYS_H