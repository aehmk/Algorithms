#include <iostream>
#include "Std2DArrays.h"

// Function to print a 2D array
void printArray(int rows, int cols, int** array) {
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            std::cout << array[i][j] << "\t";
        }
        std::cout << std::endl;
    }
}

int main() {
    int rows = 4;
    int cols = 4;
    
    // Dynamically allocate a 2D array
    int** array = new int*[rows];
    for (int i = 0; i < rows; ++i) {
        array[i] = new int[cols];
    }

    // Fill array using the SW HOR method
    fillArray(rows, cols, array);

    // Print the filled array
    std::cout << "Filled Array (SW HOR):" << std::endl;
    printArray(rows, cols, array);

    // Deallocate the 2D array
    for (int i = 0; i < rows; ++i) {
        delete[] array[i];
    }
    delete[] array;

    return 0;
}
