#include "Std2DArrays.h"

// Function to fill a 2D array from the South-West horizontally (SW HOR)
void fillArray(int rows, int cols, int** array) {
    int num = 1; // Starting number
    
    // Fill from the bottom row upwards
    for (int row = rows - 1; row >= 0; --row) {
        for (int col = 0; col < cols; ++col) {
            array[row][col] = num++;
        }
    }
}